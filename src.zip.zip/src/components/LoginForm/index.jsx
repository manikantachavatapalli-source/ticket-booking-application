import './index.css'
import { useState } from 'react'
import Cookies from 'js-cookie'
import {useNavigate, Navigate, Link} from 'react-router-dom'

const LoginForm = () => {
    const navigate = useNavigate()
    // localStorage.setItem('details', JSON.stringify({name:'123', password:'123'}))
    
    const [nameInput, setName] = useState('')
    const [passwordInput, setPassword] = useState('')
    const [incorrectMessage ,setIncoorectMessage] = useState('')

    const onChangeName = (event) => {
        setName(event.target.value)
        setIncoorectMessage('')
    }

    const onChangePassword = (event) => { 
        setPassword(event.target.value)
        setIncoorectMessage('')
    }

    const nameOnBlur = () => {
        if (nameInput === '') {
            document.getElementById('nameError').textContent = '*Please Enter the Name'
        }
        else {
            document.getElementById('nameError').textContent = ''
        }
    }

    const passwordOnBlur = () => {
        if (passwordInput === '') {
            document.getElementById('passwordError').textContent = '*Please Enter the Password'
        }
        else {
            document.getElementById('passwordError').textContent = ''
        }
    }

    const formSubmiting = (event) => {
        event.preventDefault()
        if (nameInput === "" || passwordInput === "") {
            if (nameInput === '') {
                document.getElementById('nameError').textContent = '*Please Enter the Name'
            }
            if (passwordInput === '') {
                document.getElementById('passwordError').textContent = '*Please Enter the Password'
            }
        }
        else {
            const data = JSON.parse(localStorage.getItem('details'))
            const {name, password} = data

            if ((nameInput === '123') && (passwordInput === '123')) {
                const value='access permitted'
                Cookies.set('Access_Token', value, {expires:10})
                navigate('/', {replace:true})
            }
            else {
                setIncoorectMessage('Please Correct Details')
                setName('')
                setPassword('')
            }  
        }
    }
    const access_token = Cookies.get('Access_Token')
    if (access_token !== undefined) {
        return <Navigate to='/' replace />
    }
    else {
        return(
            <div className='loginPage'>        
                    <img src='https://static.vecteezy.com/system/resources/previews/053/223/605/non_2x/a-bus-and-a-train-are-next-to-a-globe-vector.jpg' className='loginImage' alt='login page img' />            
                <form className='formSection' onSubmit={formSubmiting}>
                    <div className="inputBox">
                        <h1 className='label'>NAME</h1>
                        <input type="text" placeholder="NAME" className='input' onChange={onChangeName} onBlur={nameOnBlur} value={nameInput} />
                        <p className='error-message' id='nameError'></p>
                    </div>
                    <div className="inputBox">
                        <h1 className='label'>PASSWORD</h1>
                        <input type="text" placeholder="PASSWORD" className='input' onChange={onChangePassword} onBlur={passwordOnBlur} value={passwordInput} />
                        <p className='error-message' id='passwordError'></p>
                    </div>
                    <div className='btn-container'>
                        <button className='loginBtn' type='submit'>  Login </button>
                        <p>{incorrectMessage}</p>
                    </div>
                </form>
            </div>
            )
    }
}
export default LoginForm